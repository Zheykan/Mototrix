<template>
  <div class="empleado">
    <f_empleado @refresh="refrescar"/>
  </div>
</template>


<script>
import f_empleado from '@/components/f_Empleados.vue';
import axios from "axios";

export default {
  name: 'Empleado-View',
  components: {
    f_empleado,
  },
  data: () => ({
    empleados: [],
  }),
  mounted() {
    this.getEmpleados();
  },
  methods: {
    refrescar() {
      this.getEmpleados();
    },
    getEmpleados() {
      axios
        .get("http://localhost:9090/api/empleado/listar")
        .then((response) => {
          this.empleados = response.data;
        });
    },
  },
};
</script>
