<template>
  <div class="vehiculo">
    <f_Vehiculo/>
  </div>
</template>

<script>
import f_Vehiculo from '@/components/f_Vehiculo.vue'

export default {
  name: 'Vehiculo-View',
  components: {
    f_Vehiculo,
  },
};
</script>

<style>

</style>