
<template>
  <div class="f_empleado">
    <fieldset>
      <legend>Formulario Registro empleado</legend>
      <form @submit.prevent="guardar">
        <label for="idEmpleado">Id empleado</label><br />
        <input
          type="number"
          name="idEmpleado"
          id="idEmpleado"
          v-model="empleado.idEmpleado"
        /><br />

        <label for="contrasena">contraseña</label><br />
        <input
          type="password"
          name="contrasena"
          id="contrasena"
          v-model="empleado.contrasena"
        /><br />

        <label for="nombre">Nombre</label><br />
        <input
          type="text"
          name="nombre"
          id="nombre"
          v-model="empleado.nombre"
          /><br />

        <label for="telefono">Telefono</label><br />
        <input
          type="text"
          name="telefono"
          id="telefono"
          v-model="empleado.telefono"
        /><br />

        <label for="tipo">Tipo</label><br />
        <input
          type="text"
          name="tipo"
          id="tipo"
          v-model="empleado.tipo"
        /><br />

        <label for="salario">salario</label><br />
        <input
          type="number"
          name="salario"
          id="salario"
          v-model="empleado.salario"
        /><br />
        

        <button type="submit">Guardar</button>
        <button type="button" @click="eliminar(empleado.idEmpleado)">
          Eliminar
        </button>
      </form>
    </fieldset>
    <router-view />
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "f_Empleados",
  data: function () {
    return {
      empleado: {
        idEmpleado: "",
        contrasena: "",
        nombre: "",
        telefono: "",
        tipo: "",
        salario: "",
      },
    };
  },
  methods: {
    guardar() {
      axios
        .post("http://localhost:9090/api/empleado", this.empleado)
        .then((data) => {
          console.log("response", data);
          this.$emit("refresh");
        });
    },

    eliminar(id) {
      axios
        .delete("http://localhost:9090/api/empleado/" + id)
        .then((data) => {
          console.log("response", data);
          this.empleado.idEmpleado = null;
          this.$emit("refresh");
        })
        .catch(() => {
          alert("El empleado seleccionado no existe");
        });

      console.log(id);
    },
  },
  
};
</script>