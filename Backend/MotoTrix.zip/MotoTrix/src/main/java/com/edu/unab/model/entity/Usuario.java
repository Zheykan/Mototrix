package com.edu.unab.model.entity;

public class Usuario {

}
